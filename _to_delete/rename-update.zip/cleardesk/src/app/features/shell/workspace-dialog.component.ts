import { ChangeDetectionStrategy, Component, OnInit, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BACKEND } from '../../core/backend';
import { EXPIRY_CHOICES, WORKSPACE_COLORS, WORKSPACE_ICONS, Workspace, WorkspaceIcon } from '../../core/models';
import { ToastService } from '../../core/toast.service';
import { DialogComponent } from '../../shared/dialog.component';
import { IconComponent } from '../../shared/icon.component';

/** Create or edit a workspace: name, colour, glyph and expiry. */
@Component({
  selector: 'cd-workspace-dialog',
  imports: [DialogComponent, IconComponent, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <cd-dialog [heading]="workspace() ? 'Edit workspace' : 'New workspace'" [width]="460" (closed)="closed.emit()">
      <form id="ws-form" (ngSubmit)="save()" class="form">
        <div class="preview">
          <span class="tile" [style.background]="color()"><cd-icon [name]="icon()" [size]="26" [stroke]="2" /></span>
          <div class="field grow">
            <label for="ws-name">Name</label>
            <input id="ws-name" name="name" autofocus [ngModel]="name()" (ngModelChange)="name.set($event)"
              placeholder="e.g. Client Chris — Website" maxlength="80" />
          </div>
        </div>

        <div class="field">
          <span class="lbl" id="ws-color-l">Colour</span>
          <div class="swatches" role="radiogroup" aria-labelledby="ws-color-l">
            @for (c of colors; track c) {
              <button type="button" role="radio" [attr.aria-checked]="c === color()" [attr.aria-label]="c"
                class="sw" [style.background]="c" (click)="color.set(c)">
                @if (c === color()) { <cd-icon name="check" [size]="14" [stroke]="3" /> }
              </button>
            }
          </div>
        </div>

        <div class="field">
          <span class="lbl" id="ws-icon-l">Icon</span>
          <div class="icons" role="radiogroup" aria-labelledby="ws-icon-l">
            @for (i of icons; track i) {
              <button type="button" role="radio" [attr.aria-checked]="i === icon()" [attr.aria-label]="i"
                class="ic" [class.on]="i === icon()" (click)="icon.set(i)"><cd-icon [name]="i" [size]="16" /></button>
            }
          </div>
        </div>

        <div class="field">
          <span class="lbl" id="ws-exp-l">{{ workspace() ? 'Expires' : 'Archive automatically after' }}</span>
          <div class="segmented" role="group" aria-labelledby="ws-exp-l">
            @if (workspace()) {
              <button type="button" [attr.aria-pressed]="expiry() === null" (click)="expiry.set(null)">Keep current</button>
            }
            @for (e of expiries; track e.days) {
              <button type="button" [attr.aria-pressed]="expiry() === e.days" (click)="expiry.set(e.days)">{{ e.label }}</button>
            }
          </div>
          <small>Expired workspaces move to the Archive. Nothing is deleted.</small>
        </div>
      </form>
      <ng-container footer>
        <button type="button" class="btn" (click)="closed.emit()">Cancel</button>
        <button type="submit" form="ws-form" class="btn primary" [disabled]="busy() || !name().trim()">
          {{ workspace() ? 'Save' : 'Create workspace' }}
        </button>
      </ng-container>
    </cd-dialog>
  `,
  styles: `
    .form { display: flex; flex-direction: column; gap: 18px; }
    .preview { display: flex; align-items: flex-end; gap: 14px; }
    .grow { flex: 1; }
    .tile { width: 56px; height: 56px; flex: none; border-radius: 14px; display: flex; align-items: center; justify-content: center; color: #fff; box-shadow: inset 0 -2px 0 rgba(0,0,0,.15); }
    .lbl { font-size: var(--fs-xs); font-weight: 600; color: var(--text-2); }
    small { font-size: var(--fs-xs); color: var(--text-3); }
    .swatches, .icons { display: flex; flex-wrap: wrap; gap: 8px; }
    .sw { width: 30px; height: 30px; border-radius: 50%; border: 0; color: #fff; display: flex; align-items: center; justify-content: center; box-shadow: inset 0 -1px 0 rgba(0,0,0,.15); }
    .sw[aria-checked='true'] { box-shadow: 0 0 0 2px var(--bg-elev), 0 0 0 4px currentColor; outline: none; }
    .ic { width: 36px; height: 36px; border-radius: var(--r-ctl); border: 1px solid var(--border); background: var(--bg-elev); color: var(--text-2); display: flex; align-items: center; justify-content: center;
      &.on { border-color: var(--accent); color: var(--accent-text); background: var(--accent-soft); } }
  `,
})
export class WorkspaceDialogComponent implements OnInit {
  private readonly backend = inject(BACKEND);
  private readonly toast = inject(ToastService);
  readonly workspace = input<Workspace | null>(null);
  readonly saved = output<Workspace>();
  readonly closed = output<void>();

  protected readonly colors = WORKSPACE_COLORS;
  protected readonly icons = WORKSPACE_ICONS;
  protected readonly expiries = EXPIRY_CHOICES;

  protected readonly name = signal('');
  protected readonly color = signal(WORKSPACE_COLORS[0]);
  protected readonly icon = signal<WorkspaceIcon>('folder');
  /** Days; null = leave as is (edit) / use the default (create). */
  protected readonly expiry = signal<number | null>(null);
  protected readonly busy = signal(false);

  ngOnInit() {
    const w = this.workspace();
    if (w) {
      this.name.set(w.name);
      this.color.set(w.color);
      this.icon.set(w.icon);
    } else {
      this.color.set(WORKSPACE_COLORS[Math.floor(Math.random() * WORKSPACE_COLORS.length)]);
      this.backend.getSettings().then((s) => this.expiry.set(s.defaultExpiryDays));
    }
  }

  protected async save() {
    if (!this.name().trim() || this.busy()) return;
    this.busy.set(true);
    try {
      const w = this.workspace();
      const res = w
        ? await this.backend.updateWorkspace(w.id, {
            name: this.name(), color: this.color(), icon: this.icon(), expiryDays: this.expiry() ?? undefined,
          })
        : await this.backend.createWorkspace(this.name(), this.color(), this.icon(), this.expiry() ?? undefined);
      this.saved.emit(res);
    } catch (e) {
      this.toast.error(e);
    } finally {
      this.busy.set(false);
    }
  }
}
