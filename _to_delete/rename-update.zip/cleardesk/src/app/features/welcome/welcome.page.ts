import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { Router } from '@angular/router';
import { BACKEND } from '../../core/backend';
import { WORKSPACE_COLORS, WorkspaceIcon } from '../../core/models';
import { PlatformService } from '../../core/platform.service';
import { ToastService } from '../../core/toast.service';
import { AppIconComponent } from '../../shared/app-icon.component';
import { IconComponent } from '../../shared/icon.component';
import { KbdComponent } from '../../shared/kbd.component';

/** First run: one sentence of what this is, the shortcut, and a first workspace. */
@Component({
  selector: 'cd-welcome-page',
  imports: [AppIconComponent, IconComponent, KbdComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="wrap">
      <cd-app-icon [size]="84" />
      <h1>Keep today’s work one shortcut away</h1>
      <p class="lead">Put the files, links and notes for one job in a workspace. Find any of them in a second, from any app.</p>

      <div class="steps">
        <div class="step"><span class="n">1</span><div><strong>Make a workspace</strong><small>One per client, bug or assignment.</small></div></div>
        <div class="step"><span class="n">2</span><div><strong>Drop files in</strong><small>ClearDesk keeps a link. Originals stay put.</small></div></div>
        <div class="step"><span class="n">3</span><div><strong>Press <cd-kbd [keys]="platform.keys('CommandOrControl+Shift+Space')" /></strong><small>Type, then Enter. Or drag the file out.</small></div></div>
      </div>

      <form class="create" (submit)="$event.preventDefault(); create()">
        <label for="first-ws" class="sr-only">Workspace name</label>
        <input id="first-ws" autofocus [value]="name()" (input)="name.set($any($event.target).value)" placeholder="Name your first workspace, e.g. Client Chris — Website" maxlength="80" />
        <button type="submit" class="btn primary" [disabled]="!name().trim() || busy()">Create workspace</button>
      </form>
      <div class="ideas">
        @for (s of ideas; track s.name) {
          <button type="button" class="chip" (click)="name.set(s.name)"><cd-icon [name]="s.icon" [size]="12" />{{ s.name }}</button>
        }
      </div>

      <p class="private"><cd-icon name="shield" [size]="14" />No account. No tracking. Everything stays on this computer.</p>
    </div>
  `,
  styles: `
    .wrap { max-width: 640px; margin: 0 auto; padding: 56px 32px; display: flex; flex-direction: column; align-items: center; text-align: center; gap: 14px; }
    h1 { margin-top: 10px; font-family: var(--font-display); font-size: 30px; font-weight: 700; letter-spacing: -0.02em; }
    .lead { max-width: 480px; color: var(--text-2); font-size: 15px; line-height: 1.55; }
    .steps { width: 100%; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px; margin: 16px 0 10px; }
    .step { display: flex; gap: 10px; text-align: left; padding: 14px; border: 1px solid var(--border); border-radius: var(--r-card); background: var(--bg-elev);
      strong { display: block; font-size: var(--fs-sm); margin-bottom: 3px; } small { font-size: var(--fs-xs); color: var(--text-3); line-height: 1.4; } }
    .n { flex: none; width: 22px; height: 22px; border-radius: 6px; background: var(--accent-soft); color: var(--accent-text); font-size: 12px; font-weight: 700; display: flex; align-items: center; justify-content: center; }
    .create { width: 100%; display: flex; gap: 8px;
      input { flex: 1; min-width: 0; height: 40px; padding: 0 12px; border-radius: var(--r-ctl); border: 1px solid var(--border-strong); background: var(--bg-elev); font-size: var(--fs-md);
        &:focus { border-color: var(--accent); box-shadow: 0 0 0 1px var(--accent); } }
      .btn { height: 40px; } }
    .ideas { display: flex; flex-wrap: wrap; justify-content: center; gap: 6px; .chip:hover { border-color: var(--accent); color: var(--text); } }
    .private { display: flex; align-items: center; gap: 8px; margin-top: 18px; font-size: var(--fs-xs); color: var(--text-3); cd-icon { color: var(--accent-text); } }
    @media (max-width: 700px) { .steps { grid-template-columns: minmax(0, 1fr); } .create { flex-direction: column; } }
  `,
})
export class WelcomePage {
  private readonly backend = inject(BACKEND);
  private readonly router = inject(Router);
  private readonly toast = inject(ToastService);
  protected readonly platform = inject(PlatformService);
  protected readonly name = signal('');
  protected readonly busy = signal(false);
  protected readonly ideas: { name: string; icon: WorkspaceIcon }[] = [
    { name: 'Client website', icon: 'globe' },
    { name: 'Bug fix', icon: 'bug' },
    { name: 'Invoices this month', icon: 'receipt' },
    { name: 'University assignment', icon: 'book' },
  ];

  protected async create() {
    const n = this.name().trim();
    if (!n) return;
    this.busy.set(true);
    try {
      const idea = this.ideas.find((i) => i.name === n);
      const w = await this.backend.createWorkspace(n, WORKSPACE_COLORS[0], idea?.icon ?? 'folder');
      void this.router.navigate(['/w', w.id]);
    } catch (e) {
      this.toast.error(e);
    } finally {
      this.busy.set(false);
    }
  }
}
