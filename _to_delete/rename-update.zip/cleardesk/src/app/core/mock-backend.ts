import type { Backend, DropEvent, SettingsPatch, Unlisten, WorkspacePatch } from './backend';
import type {
  AddResult, AppInfo, Item, ItemKind, LicenseStatus, Materials, ResumeInfo, SearchHit, Settings, Suggestions,
  TextPreview, Workspace, WorkspaceIcon,
} from './models';

/**
 * Browser-only stand-in for the Rust side, with the demo data from the
 * design canvas. Lets `npm start` run the full UI without Tauri.
 * Open http://localhost:4200/#/panel to see the quick panel.
 */
const KEY = 'cleardesk.mock.v1';
const H = 3_600_000;
const D = 24 * H;

interface MockState {
  workspaces: Workspace[];
  items: Item[];
  settings: Settings;
}

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function guessOs(): AppInfo['os'] {
  const ua = navigator.userAgent;
  return /Mac/i.test(ua) ? 'macos' : /Win/i.test(ua) ? 'windows' : 'linux';
}

function seed(): MockState {
  const now = Date.now();
  const os = guessOs();
  const home = os === 'windows' ? 'C:\\Users\\William' : '/Users/william';
  const sep = os === 'windows' ? '\\' : '/';
  const p = (...parts: string[]) => [home, ...parts].join(sep);
  const ws = (id: string, name: string, color: string, icon: WorkspaceIcon, expiresIn: number | null, opened: number): Workspace => ({
    id, name, color, icon, createdAt: now - 9 * D, updatedAt: now - opened, lastOpenedAt: now - opened,
    expiresAt: expiresIn === null ? null : now + expiresIn, archivedAt: null,
    lastSearch: id === 'chris' ? 'footer' : null, itemCount: 0,
  });
  const workspaces = [
    ws('chris', 'Chris — Website Redesign', '#14B8A6', 'globe', 6 * D, 20 * H),
    ws('bug', 'Payment bug #482', '#F59E0B', 'bug', 1 * D, 2 * D),
    ws('invoices', 'October invoices', '#8B5CF6', 'receipt', null, 3 * D),
    ws('uni', 'University assignment', '#F43F5E', 'book', 30 * D, 5 * D),
  ];
  let n = 0;
  const it = (workspaceId: string, kind: ItemKind, title: string, extra: Partial<Item> = {}): Item => ({
    id: `i${++n}`, workspaceId, kind, title, path: null, url: null, noteBody: null,
    ext: kind === 'folder' || kind === 'link' || kind === 'note' ? null : title.split('.').pop()!.toLowerCase(),
    size: null, modifiedAt: now - 2 * D, pinned: false, addedAt: now - (10 - n) * H,
    lastOpenedAt: null, status: 'available', movedTo: null, ...extra,
  });
  const items: Item[] = [
    it('chris', 'file', 'hero-final.png', { path: p('Desktop', 'Chris', 'hero-final.png'), size: 2_400_000, pinned: true, lastOpenedAt: now - 20 * H }),
    it('chris', 'file', 'Chris_Brief_v2.pdf', { path: p('Documents', 'Clients', 'Chris', 'Chris_Brief_v2.pdf'), size: 840_000, pinned: true, lastOpenedAt: now - 21 * H }),
    it('chris', 'link', 'Staging site', { url: 'https://staging.example.com', pinned: true, lastOpenedAt: now - 20.5 * H }),
    it('chris', 'note', 'Footer feedback', { noteBody: 'Client wants a darker footer and a bigger “Book a call” button. Send v3 by Friday.', modifiedAt: now - 20 * H }),
    it('chris', 'screenshot', os === 'macos' ? 'Screenshot 2026-10-22 at 10.42.15.png' : 'Screenshot 2026-10-22 104215.png', { path: p('Pictures', 'Screenshots', 'Screenshot.png'), size: 610_000 }),
    it('chris', 'file', 'Homepage copy.docx', { path: p('Documents', 'Clients', 'Chris', 'Homepage copy.docx'), size: 38_000, lastOpenedAt: now - 20.2 * H }),
    it('chris', 'file', 'logo-pack.zip', { path: p('Downloads', 'logo-pack.zip'), size: 4_800_000 }),
    it('chris', 'folder', 'assets', { path: p('Desktop', 'Chris', 'assets') }),
    it('chris', 'file', 'Contract_signed.pdf', { path: p('Documents', 'Clients', 'Chris', 'Contract_signed.pdf'), size: 210_000, status: 'moved', movedTo: p('Downloads', 'Contract_signed.pdf') }),
    it('chris', 'file', 'brand-colors.png', { path: p('Desktop', 'Chris', 'brand-colors.png'), size: 120_000, status: 'missing' }),
    it('chris', 'file', 'footage-raw.mov', { path: 'E:\\Footage\\footage-raw.mov', ext: 'mov', size: 1_900_000_000, status: 'offline_drive' }),
    it('chris', 'note', 'Client call notes', { noteBody: 'Pages: Home, Services, About, Contact.\nUrdu version later.\nDomain renewal in March.', modifiedAt: now - 3 * D }),
    it('bug', 'file', 'payment-error-log.txt', { path: p('Downloads', 'payment-error-log.txt'), size: 14_000, lastOpenedAt: now - 2 * D }),
    it('bug', 'screenshot', 'Screenshot 2026-10-21 184002.png', { path: p('Pictures', 'Screenshots', 'Screenshot2.png'), size: 980_000 }),
    it('invoices', 'file', 'Invoice_Oct_Chris.pdf', { path: p('Documents', 'Invoices', 'Invoice_Oct_Chris.pdf'), size: 96_000 }),
    it('uni', 'folder', 'Assignment 3', { path: p('Documents', 'University', 'Assignment 3') }),
  ];
  return {
    workspaces,
    items,
    settings: {
      shortcut: 'CommandOrControl+Shift+Space', defaultExpiryDays: 7, theme: 'system',
      hidePanelOnBlur: true, activeWorkspaceId: 'chris',
    },
  };
}

export class MockBackend implements Backend {
  readonly isNative = false;
  private state: MockState = this.load();
  private listeners = new Set<() => void>();
  private settingsListeners = new Set<(s: Settings) => void>();

  private load(): MockState {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return JSON.parse(raw) as MockState;
    } catch { /* private mode or blocked storage: start fresh */ }
    return seed();
  }

  private save() {
    try { localStorage.setItem(KEY, JSON.stringify(this.state)); } catch { /* ignore */ }
    queueMicrotask(() => this.listeners.forEach((l) => l()));
  }

  private withCount(w: Workspace): Workspace {
    return { ...w, itemCount: this.state.items.filter((i) => i.workspaceId === w.id).length };
  }

  private ws(id: string): Workspace {
    const w = this.state.workspaces.find((x) => x.id === id);
    if (!w) throw new Error('Not found: workspace');
    return w;
  }

  private item(id: string): Item {
    const i = this.state.items.find((x) => x.id === id);
    if (!i) throw new Error('Not found: item');
    return i;
  }

  private delay<T>(v: T): Promise<T> {
    return new Promise((r) => setTimeout(() => r(structuredClone(v)), 30));
  }

  windowLabel(): 'main' | 'panel' {
    return location.hash.startsWith('#/panel') ? 'panel' : 'main';
  }

  appInfo() { return this.delay<AppInfo>({ os: guessOs(), version: '0.1.0', dataDir: '(browser preview — nothing is saved to disk)' }); }
  materials() { return this.delay<Materials>({ main: false, panel: false }); }

  getSettings() { return this.delay(this.state.settings); }
  updateSettings(patch: SettingsPatch) {
    if (patch.shortcut && /^(commandorcontrol|ctrl|cmd)\+space$/i.test(patch.shortcut.replace(/\s/g, ''))) {
      return Promise.reject('That shortcut belongs to the system. Try Ctrl+Shift+Space or Alt+Shift+Space.');
    }
    Object.assign(this.state.settings, Object.fromEntries(Object.entries(patch).filter(([, v]) => v !== undefined)));
    this.save();
    this.settingsListeners.forEach((l) => l(this.state.settings));
    return this.delay(this.state.settings);
  }

  listWorkspaces(archived = false) {
    const list = this.state.workspaces
      .filter((w) => (archived ? w.archivedAt !== null : w.archivedAt === null))
      .sort((a, b) => (b.lastOpenedAt ?? b.createdAt) - (a.lastOpenedAt ?? a.createdAt))
      .map((w) => this.withCount(w));
    return this.delay(list);
  }
  activeWorkspace() {
    const id = this.state.settings.activeWorkspaceId;
    const w = this.state.workspaces.find((x) => x.id === id && !x.archivedAt) ?? this.state.workspaces.find((x) => !x.archivedAt);
    return this.delay(w ? this.withCount(w) : null);
  }
  setActiveWorkspace(id: string) {
    const w = this.ws(id);
    w.lastOpenedAt = Date.now();
    this.state.settings.activeWorkspaceId = id;
    this.save();
    return this.delay(this.withCount(w));
  }
  createWorkspace(name: string, color: string, icon: WorkspaceIcon, expiryDays?: number) {
    if (!name.trim()) return Promise.reject('Give the workspace a name.');
    const days = expiryDays ?? this.state.settings.defaultExpiryDays;
    const now = Date.now();
    const w: Workspace = {
      id: uid(), name: name.trim(), color, icon, createdAt: now, updatedAt: now, lastOpenedAt: now,
      expiresAt: days > 0 ? now + days * D : null, archivedAt: null, lastSearch: null, itemCount: 0,
    };
    this.state.workspaces.push(w);
    this.state.settings.activeWorkspaceId = w.id;
    this.save();
    return this.delay(w);
  }
  updateWorkspace(id: string, patch: WorkspacePatch) {
    const w = this.ws(id);
    if (patch.name !== undefined) w.name = patch.name.trim() || w.name;
    if (patch.color) w.color = patch.color;
    if (patch.icon) w.icon = patch.icon;
    if (patch.expiryDays !== undefined) w.expiresAt = patch.expiryDays > 0 ? Date.now() + patch.expiryDays * D : null;
    this.save();
    return this.delay(this.withCount(w));
  }
  archiveWorkspace(id: string) { this.ws(id).archivedAt = Date.now(); this.save(); return this.delay(undefined); }
  restoreWorkspace(id: string) {
    const w = this.ws(id);
    w.archivedAt = null;
    if (w.expiresAt && w.expiresAt < Date.now()) w.expiresAt = null;
    this.save();
    return this.delay(undefined);
  }
  deleteWorkspace(id: string) {
    this.state.workspaces = this.state.workspaces.filter((w) => w.id !== id);
    this.state.items = this.state.items.filter((i) => i.workspaceId !== id);
    this.save();
    return this.delay(undefined);
  }

  listItems(workspaceId: string) {
    const list = this.state.items
      .filter((i) => i.workspaceId === workspaceId)
      .sort((a, b) => Number(b.pinned) - Number(a.pinned) || (b.lastOpenedAt ?? b.addedAt) - (a.lastOpenedAt ?? a.addedAt));
    return this.delay(list);
  }
  addPaths(workspaceId: string, paths: string[]) {
    const added: Item[] = [];
    for (const path of paths) {
      const title = path.split(/[\\/]/).pop() || path;
      const ext = title.includes('.') ? title.split('.').pop()!.toLowerCase() : null;
      const shot = /^screen ?shot/i.test(title);
      const item: Item = {
        id: uid(), workspaceId, kind: ext ? (shot ? 'screenshot' : 'file') : 'folder', title, path, url: null,
        noteBody: null, ext, size: 120_000, modifiedAt: Date.now(), pinned: false, addedAt: Date.now(),
        lastOpenedAt: null, status: 'available', movedTo: null,
      };
      this.state.items.push(item);
      added.push(item);
    }
    this.save();
    return this.delay<AddResult>({ added, skipped: [] });
  }
  addLink(workspaceId: string, url: string, title?: string) {
    if (!/^https?:\/\//.test(url)) return Promise.reject('Links must start with http:// or https://');
    const item = this.newItem(workspaceId, 'link', title || url.replace(/^https?:\/\//, ''), { url });
    return this.delay(item);
  }
  addNote(workspaceId: string, title: string, body: string) {
    return this.delay(this.newItem(workspaceId, 'note', title.trim() || 'Untitled note', { noteBody: body, modifiedAt: Date.now() }));
  }
  private newItem(workspaceId: string, kind: ItemKind, title: string, extra: Partial<Item>): Item {
    const item: Item = {
      id: uid(), workspaceId, kind, title, path: null, url: null, noteBody: null, ext: null, size: null,
      modifiedAt: null, pinned: false, addedAt: Date.now(), lastOpenedAt: null, status: 'available', movedTo: null, ...extra,
    };
    this.state.items.push(item);
    this.save();
    return item;
  }
  updateNote(id: string, title: string, body: string) {
    const i = this.item(id);
    i.title = title.trim() || i.title;
    i.noteBody = body;
    i.modifiedAt = Date.now();
    this.save();
    return this.delay(i);
  }
  setPinned(id: string, pinned: boolean) { const i = this.item(id); i.pinned = pinned; this.save(); return this.delay(i); }
  moveItem(id: string, workspaceId: string) { const i = this.item(id); i.workspaceId = workspaceId; this.save(); return this.delay(i); }
  removeItem(id: string) {
    const i = this.item(id);
    this.state.items = this.state.items.filter((x) => x.id !== id);
    this.save();
    return this.delay(i);
  }
  restoreItem(item: Item) { this.state.items.push({ ...item, id: uid() }); this.save(); return this.delay(item); }

  openItem(id: string) {
    const i = this.item(id);
    if (i.status !== 'available' && i.kind !== 'note' && i.kind !== 'link') {
      return Promise.reject('This file was moved or deleted. Search for it again or remove it from ClearDesk.');
    }
    i.lastOpenedAt = Date.now();
    this.ws(i.workspaceId).lastOpenedAt = Date.now();
    if (i.kind === 'link' && i.url) window.open(i.url, '_blank', 'noopener');
    this.save();
    return this.delay(undefined);
  }
  revealItem(_id: string) { return this.delay(undefined); }
  async copyPath(id: string) {
    const i = this.item(id);
    try { await navigator.clipboard.writeText(i.path ?? i.url ?? i.noteBody ?? ''); } catch { /* not allowed in this context */ }
  }
  copyFile(_id: string) { return this.delay(undefined); }
  textPreview(id: string) {
    const i = this.item(id);
    return this.delay<TextPreview>({
      text: `[${new Date().toISOString()}] POST /api/checkout 502\n  at PaymentGateway.charge (gateway.ts:118)\n  retry 1/3 …\n  retry 2/3 …\n[${i.title}] payment_intent failed: card_declined`,
      truncated: false,
    });
  }
  previewSrc(_path: string) { return null; }
  startDrag(_paths: string[]) { return this.delay(undefined); }

  search(query: string, workspaceId: string | null, all: boolean, limit = 50) {
    const q = query.trim().toLowerCase();
    const active = new Set(this.state.workspaces.filter((w) => !w.archivedAt).map((w) => w.id));
    const hits: SearchHit[] = this.state.items
      .filter((i) => active.has(i.workspaceId) && (all || i.workspaceId === workspaceId))
      .map((item) => {
        const w = this.ws(item.workspaceId);
        const hay = `${item.title} ${item.path ?? ''} ${item.url ?? ''} ${item.noteBody ?? ''} ${w.name}`.toLowerCase();
        const title = item.title.toLowerCase();
        let score = !q ? 1 : title.startsWith(q) ? 800 : title.includes(q) ? 500 : hay.includes(q) ? 150 : 0;
        if (score && item.workspaceId === workspaceId) score += 300;
        if (score && item.pinned) score += 60;
        return { item, workspaceName: w.name, workspaceColor: w.color, score };
      })
      .filter((h) => h.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
    return this.delay(hits);
  }
  rememberSearch(workspaceId: string, query: string) {
    if (query.trim()) { this.ws(workspaceId).lastSearch = query.trim(); this.save(); }
    return this.delay(undefined);
  }
  suggestions(workspaceId: string) {
    const items = this.state.items.filter((i) => i.workspaceId === workspaceId);
    const pinned = items.filter((i) => i.pinned).slice(0, 5);
    const recent = items.filter((i) => !i.pinned && i.lastOpenedAt).sort((a, b) => b.lastOpenedAt! - a.lastOpenedAt!).slice(0, 5);
    const shown = new Set([...pinned, ...recent].map((i) => i.id));
    const added = items.filter((i) => !shown.has(i.id)).sort((a, b) => b.addedAt - a.addedAt).slice(0, 5);
    return this.delay<Suggestions>({ pinned, recent, added, lastSearch: this.ws(workspaceId).lastSearch });
  }
  resumeInfo(workspaceId: string) {
    const items = this.state.items.filter((i) => i.workspaceId === workspaceId);
    const opened = items.filter((i) => i.lastOpenedAt).sort((a, b) => b.lastOpenedAt! - a.lastOpenedAt!);
    const latest = opened[0]?.lastOpenedAt ?? null;
    const session = latest ? opened.filter((i) => i.kind !== 'note' && latest - i.lastOpenedAt! <= 2 * H).slice(0, 6) : [];
    const notes = items.filter((i) => i.kind === 'note').sort((a, b) => (b.modifiedAt ?? 0) - (a.modifiedAt ?? 0)).slice(0, 2);
    return this.delay<ResumeInfo>({ workspaceId, items: session, lastSearch: this.ws(workspaceId).lastSearch, notes, leftAt: latest });
  }
  async resumeWorkspace(workspaceId: string) {
    const info = await this.resumeInfo(workspaceId);
    return { opened: info.items.map((i) => i.title), failed: [] };
  }
  refreshStatus(_workspaceId?: string) { return this.delay(0); }
  relinkItem(id: string, path?: string) {
    const i = this.item(id);
    const target = path ?? i.movedTo;
    if (!target) return Promise.reject('No new location to link to.');
    i.path = target;
    i.status = 'available';
    i.movedTo = null;
    this.save();
    return this.delay(i);
  }

  pickPaths(opts: { directory: boolean }) {
    const name = opts.directory ? 'Project files' : `picked-file-${Math.floor(Math.random() * 90 + 10)}.pdf`;
    return this.delay([`/Users/william/Downloads/${name}`]);
  }

  // The demo runs as Pro so all sample workspaces are usable.
  private license: LicenseStatus = {
    pro: true, email: 'demo@cleardesk.app', customer: 'Demo', keyHint: '••••-DEMO', activatedAt: Date.now() - 5 * D,
    freeWorkspaces: 1, freeItems: 50,
  };
  private licenseListeners = new Set<() => void>();
  licenseStatus() { return this.delay(this.license); }
  activateLicense(key: string) {
    if (key.trim().length < 8) return Promise.reject('Paste the full licence key from your receipt email.');
    this.license = { ...this.license, pro: true, keyHint: `••••-${key.trim().slice(-4)}`, activatedAt: Date.now() };
    this.licenseListeners.forEach((l) => l());
    return this.delay(this.license);
  }
  deactivateLicense() {
    this.license = { ...this.license, pro: false, email: null, customer: null, keyHint: null, activatedAt: null };
    this.licenseListeners.forEach((l) => l());
    return this.delay(this.license);
  }
  onLicenseChanged(cb: () => void): Promise<Unlisten> {
    this.licenseListeners.add(cb);
    return Promise.resolve(() => this.licenseListeners.delete(cb));
  }
  openUrl(url: string) { window.open(url, '_blank', 'noopener'); return this.delay(undefined); }

  hidePanel() { return this.delay(undefined); }
  showPanel() { window.open('#/panel', '_blank'); return this.delay(undefined); }
  showWorkspaceWindow(route?: string) { if (this.windowLabel() === 'panel') location.hash = `#${route ?? '/'}`; return this.delay(undefined); }
  minimize() { return this.delay(undefined); }
  toggleMaximize() { return this.delay(undefined); }
  closeWindow() { return this.delay(undefined); }

  onDataChanged(cb: () => void): Promise<Unlisten> {
    this.listeners.add(cb);
    // Other tabs (e.g. the panel opened in a second tab) see changes too.
    const onStorage = (e: StorageEvent) => { if (e.key === KEY) { this.state = this.load(); cb(); } };
    window.addEventListener('storage', onStorage);
    return Promise.resolve(() => { this.listeners.delete(cb); window.removeEventListener('storage', onStorage); });
  }
  onSettingsChanged(cb: (s: Settings) => void): Promise<Unlisten> {
    this.settingsListeners.add(cb);
    return Promise.resolve(() => this.settingsListeners.delete(cb));
  }
  onPanelShown(cb: () => void): Promise<Unlisten> {
    const f = () => cb();
    window.addEventListener('focus', f);
    return Promise.resolve(() => window.removeEventListener('focus', f));
  }
  onNavigate(_cb: (route: string) => void): Promise<Unlisten> { return Promise.resolve(() => {}); }
  onDragDrop(cb: (e: DropEvent) => void): Promise<Unlisten> {
    // Browsers don't expose real paths; use the file names so the flow can be tried.
    let depth = 0;
    const enter = (e: DragEvent) => { e.preventDefault(); if (depth++ === 0) cb({ type: 'enter', paths: [] }); };
    const over = (e: DragEvent) => e.preventDefault();
    const leave = () => { if (--depth <= 0) { depth = 0; cb({ type: 'leave' }); } };
    const drop = (e: DragEvent) => {
      e.preventDefault();
      depth = 0;
      const names = Array.from(e.dataTransfer?.files ?? []).map((f) => `/Users/william/Desktop/${f.name}`);
      cb({ type: 'drop', paths: names });
    };
    window.addEventListener('dragenter', enter);
    window.addEventListener('dragover', over);
    window.addEventListener('dragleave', leave);
    window.addEventListener('drop', drop);
    return Promise.resolve(() => {
      window.removeEventListener('dragenter', enter);
      window.removeEventListener('dragover', over);
      window.removeEventListener('dragleave', leave);
      window.removeEventListener('drop', drop);
    });
  }
}
