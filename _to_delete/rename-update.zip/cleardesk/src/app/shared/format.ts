import { Item, ItemStatus, Workspace } from '../core/models';

const MIN = 60_000;
const HOUR = 60 * MIN;
const DAY = 24 * HOUR;

/** "2m", "3h", "Yesterday", "Mon", "12 Oct" — short, for list rows. */
export function shortAgo(ts: number | null, now = Date.now()): string {
  if (!ts) return '';
  const d = now - ts;
  if (d < MIN) return 'now';
  if (d < HOUR) return `${Math.floor(d / MIN)}m`;
  if (d < DAY) return `${Math.floor(d / HOUR)}h`;
  if (d < 2 * DAY) return 'Yday';
  if (d < 7 * DAY) return new Date(ts).toLocaleDateString(undefined, { weekday: 'short' });
  return new Date(ts).toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
}

/** "25 min ago", "yesterday at 6:40 PM". */
export function longAgo(ts: number | null, now = Date.now()): string {
  if (!ts) return 'never';
  const d = now - ts;
  if (d < MIN) return 'just now';
  if (d < HOUR) return `${Math.floor(d / MIN)} min ago`;
  const time = new Date(ts).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  const today = new Date(now).toDateString() === new Date(ts).toDateString();
  if (today) return `today at ${time}`;
  const y = new Date(now - DAY).toDateString() === new Date(ts).toDateString();
  if (y) return `yesterday at ${time}`;
  return `${new Date(ts).toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'short' })} at ${time}`;
}

export function fileSize(bytes: number | null): string {
  if (bytes === null || bytes === undefined) return '';
  if (bytes < 1024) return `${bytes} B`;
  const units = ['KB', 'MB', 'GB', 'TB'];
  let v = bytes / 1024;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
  return `${v >= 10 ? Math.round(v) : v.toFixed(1)} ${units[i]}`;
}

export function expiryLabel(w: Pick<Workspace, 'expiresAt'>, now = Date.now()): string {
  if (!w.expiresAt) return 'Never expires';
  const d = w.expiresAt - now;
  if (d <= 0) return 'Expired';
  if (d < HOUR) return 'Expires in under an hour';
  if (d < DAY) return `Expires in ${Math.ceil(d / HOUR)} h`;
  const days = Math.ceil(d / DAY);
  return days === 1 ? 'Expires tomorrow' : `Expires in ${days} days`;
}

/** Parent folder for display: "Desktop › Chris" (mac) or "Desktop\Chris" (win). */
export function shortLocation(path: string | null, mac: boolean): string {
  if (!path) return '';
  const parts = path.split(/[\\/]/).filter(Boolean);
  parts.pop();
  const homeIdx = parts.findIndex((p, i) => (p === 'Users' || p === 'home') && i < 2);
  const rel = homeIdx >= 0 ? parts.slice(homeIdx + 2) : parts;
  const tail = rel.slice(-2);
  if (!tail.length) return mac ? 'Home' : parts[0] ?? '';
  return tail.join(mac ? ' › ' : '\\');
}

export function kindLabel(it: Pick<Item, 'kind' | 'ext'>): string {
  switch (it.kind) {
    case 'folder': return 'Folder';
    case 'link': return 'Link';
    case 'note': return 'Note';
    case 'screenshot': return 'Screenshot';
    default: return it.ext ? `${it.ext.toUpperCase()} file` : 'File';
  }
}

export function itemSubtitle(it: Item, mac: boolean): string {
  if (it.kind === 'link') return it.url?.replace(/^https?:\/\//, '').replace(/\/$/, '') ?? 'Link';
  if (it.kind === 'note') return `Note · edited ${shortAgo(it.modifiedAt) || 'now'}`;
  const loc = shortLocation(it.path, mac);
  const size = it.kind === 'folder' ? '' : fileSize(it.size);
  return [loc, size].filter(Boolean).join(' · ');
}

export const STATUS_COPY: Record<ItemStatus, { label: string; tone: 'ok' | 'warn' | 'bad'; help: string }> = {
  available: { label: 'Available', tone: 'ok', help: '' },
  moved: { label: 'Moved', tone: 'warn', help: 'This file moved. ClearDesk found a match.' },
  missing: { label: 'Missing', tone: 'bad', help: 'This file was moved or deleted. Search for it again or remove it from ClearDesk.' },
  offline_drive: { label: 'Drive offline', tone: 'warn', help: 'The drive this file is on is not connected.' },
  permission_required: { label: 'No access', tone: 'warn', help: 'ClearDesk is not allowed to read this file.' },
};

export function isImage(it: Pick<Item, 'kind' | 'ext'>): boolean {
  return it.kind === 'screenshot' || ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg'].includes((it.ext ?? '').toLowerCase());
}

export function isText(it: Pick<Item, 'ext'>): boolean {
  return ['txt', 'md', 'log', 'csv', 'json', 'xml', 'yml', 'yaml', 'toml', 'ini', 'html', 'css', 'js', 'ts', 'rs', 'py', 'java', 'cs', 'sql', 'sh', 'ps1']
    .includes((it.ext ?? '').toLowerCase());
}
